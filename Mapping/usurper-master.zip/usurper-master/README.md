# usurper

Usurper: The Medieval Strategy Game.

Usurper, is a turn-based, medieval strategy game, built around a number of tropic fantasy game concepts, including: RPG, Fantasy Racial Tropes, Rogue-Like, and other components to build a game that is both serious, but, pokes fun at a number of components of the genre.

In Usurper, players take on the role of a would-be Usurper, who must fight the stale and unchanging political landscape to oust the current rulership and bring new life to the land.  However, there are many competing factors along the way, ranging from monthly, seasonal events, to lumbering giants and trolls, to political intrigue, and the presence of legendary monsters who would burn-down the land.  All of this added atop the need for each Usurper to keep their presence hidden from the land's ruling class, elsewise they will draw the ire of armies crashing atop them and surely remove stain of their existence from the land.
